@org.junit.jupiter.api.Test
public void ${NAME}() {
  ${BODY}
}